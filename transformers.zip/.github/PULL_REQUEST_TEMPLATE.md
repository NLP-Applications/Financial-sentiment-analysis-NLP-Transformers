<!-- This line specifies which issue to close after the pull request is merged. -->
Fixes #{issue number}
