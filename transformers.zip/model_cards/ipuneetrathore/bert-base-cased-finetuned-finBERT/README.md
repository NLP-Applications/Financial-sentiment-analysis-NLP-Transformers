## FinBERT

Code for importing and using this model is available [here](https://github.com/ipuneetrathore/BERT_models)
