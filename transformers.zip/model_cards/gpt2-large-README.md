Test the full generation capabilities here: https://transformer.huggingface.co/doc/gpt2-large
